"""Жести рукою для ПК: камера бачить руку -> виконується дія (прогортання, клавіші, клік...)."""
import json
import os
import threading
import time
import tkinter as tk
import uuid
from tkinter import messagebox, ttk

import cv2
import mediapipe as mp
import numpy as np
import pyautogui

import matcher

pyautogui.PAUSE = 0
SAVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gestures.json")
COOLDOWN_MS = 1500

ACTIONS = {
    "Прогорнути вниз (колесо миші)": lambda: pyautogui.scroll(-700),
    "Прогорнути вгору (колесо миші)": lambda: pyautogui.scroll(700),
    "Клавіша ↓ (наступне відео в TikTok web)": lambda: pyautogui.press("down"),
    "Клавіша ↑": lambda: pyautogui.press("up"),
    "Клавіша →": lambda: pyautogui.press("right"),
    "Клавіша ←": lambda: pyautogui.press("left"),
    "Клік": lambda: pyautogui.click(),
    "Подвійний клік (лайк)": lambda: pyautogui.doubleClick(),
    "Пробіл (пауза / play)": lambda: pyautogui.press("space"),
    "Назад (Alt+←)": lambda: pyautogui.hotkey("alt", "left"),
    "Гучність +": lambda: [pyautogui.press("volumeup") for _ in range(3)],
    "Гучність −": lambda: [pyautogui.press("volumedown") for _ in range(3)],
    "Наступний трек": lambda: pyautogui.press("nexttrack"),
}

BONES = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8), (5, 9), (9, 10), (10, 11),
         (11, 12), (9, 13), (13, 14), (14, 15), (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]


class Gesture:
    def __init__(self, gid, name, action, frames):
        self.id, self.name, self.action, self.frames = gid, name, action, frames
        self.features = matcher.features(frames)
        self.duration = (frames[-1][0] - frames[0][0]) if len(frames) > 1 else 0.0


def load_gestures():
    if not os.path.exists(SAVE_FILE):
        return []
    try:
        with open(SAVE_FILE, encoding="utf-8") as f:
            raw = json.load(f)
        out = []
        for o in raw:
            frames = [(fr["t"], np.array(fr["p"], dtype=np.float32).reshape(21, 3)) for fr in o["frames"]]
            out.append(Gesture(o["id"], o["name"], o["action"], frames))
        return out
    except Exception:
        return []


def save_gestures(gs):
    raw = [{"id": g.id, "name": g.name, "action": g.action,
            "frames": [{"t": t, "p": [round(float(v), 3) for v in p.ravel()]} for t, p in g.frames]} for g in gs]
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        json.dump(raw, f)


class Tracker(threading.Thread):
    """Потік камери: зчитує руку, записує або розпізнає жести."""

    def __init__(self, app):
        super().__init__(daemon=True)
        self.app = app
        self.stop_flag = False
        self.running = False
        self.hand = None
        self.recorder = None
        self.status = "Запуск камери…"

    def run(self):
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW) if os.name == "nt" else cv2.VideoCapture(0)
        if not cap.isOpened():
            self.status = "Камеру не знайдено"
            return
        hands = mp.solutions.hands.Hands(max_num_hands=1, min_detection_confidence=0.6,
                                         min_tracking_confidence=0.5)
        self.running = True
        self.status = "Працює. Покажи руку в камеру"
        buf, last_trigger = [], 0.0
        try:
            while not self.stop_flag:
                ok, frame = cap.read()
                if not ok:
                    continue
                frame = cv2.flip(frame, 1)
                res = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                t = time.monotonic() * 1000.0
                if not res.multi_hand_landmarks:
                    self.hand = None
                    continue
                pts = np.array([[l.x, l.y, l.z] for l in res.multi_hand_landmarks[0].landmark], dtype=np.float32)
                self.hand = pts
                rec = self.recorder
                if rec is not None:
                    rec((t, pts))
                    continue
                buf.append((t, pts))
                while buf and buf[0][0] < t - 4000:
                    buf.pop(0)
                if t - last_trigger < COOLDOWN_MS:
                    continue
                g = matcher.best(self.app.gestures, buf, self.app.threshold)
                if g is not None:
                    last_trigger = t
                    buf.clear()
                    try:
                        ACTIONS[g.action]()
                        self.status = f"Спрацював: {g.name}"
                    except Exception as e:  # напр. курсор у куті екрана (захист pyautogui)
                        self.status = f"Помилка дії: {e}"
        finally:
            cap.release()
            hands.close()
            self.running = False
            self.hand = None
            self.status = "Вимкнено"


def draw_hand(canvas, pts, w, h):
    canvas.delete("all")
    if pts is None:
        return
    xy = [(p[0] * w, p[1] * h) for p in pts]
    for a, b in BONES:
        canvas.create_line(*xy[a], *xy[b], fill="#4dd0e1", width=3, capstyle="round")
    for x, y in xy:
        canvas.create_oval(x - 4, y - 4, x + 4, y + 4, fill="white", outline="")


class App:
    def __init__(self, root):
        self.root = root
        root.title("Жести рукою")
        root.configure(bg="#1b1f27")
        self.gestures = load_gestures()
        self.threshold = 0.30
        self.tracker = None
        self.play_start = time.monotonic()

        left = tk.Frame(root, bg="#1b1f27")
        left.grid(row=0, column=0, padx=12, pady=12, sticky="n")
        tk.Label(left, text="Жива рука", fg="white", bg="#1b1f27", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.live = tk.Canvas(left, width=480, height=360, bg="#101820", highlightthickness=0)
        self.live.pack(pady=6)
        self.status = tk.StringVar(value="Вимкнено")
        tk.Label(left, textvariable=self.status, fg="#9fd", bg="#1b1f27").pack(anchor="w")
        self.btn = ttk.Button(left, text="Запустити стеження", command=self.toggle)
        self.btn.pack(fill="x", pady=6)
        tk.Label(left, text="Чутливість (ліво — точніше, право — легше спрацьовує)",
                 fg="white", bg="#1b1f27").pack(anchor="w")
        sc = ttk.Scale(left, from_=0.15, to=0.6, value=self.threshold, command=self.set_thr)
        sc.pack(fill="x")

        right = tk.Frame(root, bg="#1b1f27")
        right.grid(row=0, column=1, padx=12, pady=12, sticky="n")
        tk.Label(right, text="Мої жести", fg="white", bg="#1b1f27", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.lb = tk.Listbox(right, width=46, height=9, bg="#262b36", fg="white", selectbackground="#2f6f9f")
        self.lb.pack(pady=6)
        self.lb.bind("<<ListboxSelect>>", lambda e: setattr(self, "play_start", time.monotonic()))
        self.player = tk.Canvas(right, width=320, height=240, bg="#101820", highlightthickness=0)
        self.player.pack(pady=6)
        row = tk.Frame(right, bg="#1b1f27")
        row.pack(fill="x")
        ttk.Button(row, text="+ Записати жест", command=self.start_record).pack(side="left", padx=2)
        ttk.Button(row, text="Змінити дію", command=self.change_action).pack(side="left", padx=2)
        ttk.Button(row, text="Видалити", command=self.delete).pack(side="left", padx=2)

        self.refresh_list()
        self.tick()
        root.protocol("WM_DELETE_WINDOW", self.close)

    def set_thr(self, v):
        self.threshold = float(v)

    def refresh_list(self):
        self.lb.delete(0, "end")
        for g in self.gestures:
            self.lb.insert("end", f"{g.name}  →  {g.action}")

    def selected(self):
        s = self.lb.curselection()
        return self.gestures[s[0]] if s else None

    def toggle(self):
        if self.tracker and self.tracker.is_alive():
            self.tracker.stop_flag = True
            self.btn.config(text="Запустити стеження")
        else:
            self.tracker = Tracker(self)
            self.tracker.start()
            self.btn.config(text="Зупинити стеження")

    def tracking(self):
        return bool(self.tracker and self.tracker.is_alive() and self.tracker.running)

    # ---------- запис жесту ----------
    def start_record(self):
        if not self.tracking():
            messagebox.showinfo("Жести", "Спочатку натисни «Запустити стеження» і зачекай, поки з'явиться рука.")
            return
        self.rec_buf = []
        self.countdown(3)

    def countdown(self, n):
        if n > 0:
            self.status.set(f"Приготуйся… {n}")
            self.root.after(1000, lambda: self.countdown(n - 1))
        else:
            self.status.set("● ЗАПИС — роби жест!")
            self.tracker.recorder = self.rec_buf.append
            self.root.after(2500, self.finish_record)

    def finish_record(self):
        self.tracker.recorder = None
        clip = matcher.trim(list(self.rec_buf))
        if len(clip) < 3:
            messagebox.showinfo("Жести", "Руку не було видно. Спробуй ще раз.")
            return
        self.save_dialog(clip)

    def save_dialog(self, clip):
        win = tk.Toplevel(self.root)
        win.title("Новий жест")
        win.grab_set()
        pv = tk.Canvas(win, width=320, height=240, bg="#101820", highlightthickness=0)
        pv.grid(row=0, column=0, columnspan=2, padx=10, pady=10)
        tmp = Gesture("tmp", "", "", clip)
        t_start = time.monotonic()

        def anim():
            if not win.winfo_exists():
                return
            el = ((time.monotonic() - t_start) * 1000) % (tmp.duration + 700)
            draw_hand(pv, self.frame_at(clip, el), 320, 240)
            win.after(30, anim)
        anim()
        tk.Label(win, text="Назва:").grid(row=1, column=0, sticky="e")
        name = tk.StringVar(value=f"Жест {len(self.gestures) + 1}")
        tk.Entry(win, textvariable=name, width=30).grid(row=1, column=1, padx=6, pady=4)
        tk.Label(win, text="Дія:").grid(row=2, column=0, sticky="e")
        act = tk.StringVar(value=list(ACTIONS)[0])
        ttk.Combobox(win, textvariable=act, values=list(ACTIONS), state="readonly", width=40).grid(row=2, column=1, padx=6, pady=4)

        def ok():
            self.gestures.append(Gesture(uuid.uuid4().hex, name.get().strip() or "Жест", act.get(), clip))
            save_gestures(self.gestures)
            self.refresh_list()
            win.destroy()
        ttk.Button(win, text="Зберегти", command=ok).grid(row=3, column=0, pady=8)
        ttk.Button(win, text="Скасувати", command=win.destroy).grid(row=3, column=1, pady=8)

    def change_action(self):
        g = self.selected()
        if not g:
            return
        win = tk.Toplevel(self.root)
        win.title("Змінити дію")
        win.grab_set()
        act = tk.StringVar(value=g.action)
        ttk.Combobox(win, textvariable=act, values=list(ACTIONS), state="readonly", width=44).pack(padx=10, pady=10)

        def ok():
            g.action = act.get()
            save_gestures(self.gestures)
            self.refresh_list()
            win.destroy()
        ttk.Button(win, text="Гаразд", command=ok).pack(pady=8)

    def delete(self):
        g = self.selected()
        if g:
            self.gestures.remove(g)
            save_gestures(self.gestures)
            self.refresh_list()

    # ---------- віртуальна рука ----------
    @staticmethod
    def frame_at(frames, elapsed):
        t0 = frames[0][0]
        cur = frames[0][1]
        for t, p in frames:
            if t - t0 <= elapsed:
                cur = p
            else:
                break
        return cur

    def tick(self):
        if self.tracker:
            if not self.tracker.is_alive() and self.btn["text"] != "Запустити стеження":
                self.btn.config(text="Запустити стеження")
            if not self.tracker.recorder and not self.status.get().startswith(("Приготуйся", "● ЗАПИС")):
                self.status.set(self.tracker.status)
            draw_hand(self.live, self.tracker.hand, 480, 360)
        else:
            draw_hand(self.live, None, 480, 360)
        g = self.selected()
        if g and g.frames:
            el = ((time.monotonic() - self.play_start) * 1000) % (g.duration + 700)
            draw_hand(self.player, self.frame_at(g.frames, el), 320, 240)
        else:
            draw_hand(self.player, None, 320, 240)
        self.root.after(30, self.tick)

    def close(self):
        if self.tracker:
            self.tracker.stop_flag = True
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
