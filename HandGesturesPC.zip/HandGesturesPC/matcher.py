"""Порівняння жестів. Кадр = (t_мс, масив 21x3 з нормалізованими x,y,z)."""
import numpy as np

N = 16  # кількість точок після передискретизації
TRAJ_W = 3.0  # вага руху зап'ястя відносно форми руки


def _palm(p):
    return max(float(np.linalg.norm(p[0, :2] - p[9, :2])), 0.02)


def features(frames):
    """Форма руки (відносно зап'ястя) + траєкторія зап'ястя, нормовані розміром долоні."""
    if len(frames) < 3:
        return None
    t0 = frames[0][0]
    dur = max(frames[-1][0] - t0, 1.0)
    first = frames[0][1]
    scale = _palm(first)
    ts = np.array([f[0] for f in frames])
    out = []
    for i in range(N):
        tt = t0 + dur * i / (N - 1)
        p = frames[int(np.argmin(np.abs(ts - tt)))][1]
        rel = (p - p[0]) / scale
        wr = (p[0, :2] - first[0, :2]) / scale * TRAJ_W
        out.append(np.concatenate([rel.ravel(), wr]))
    return np.array(out)


def dist(a, b):
    return float(np.sqrt(np.mean((a - b) ** 2)))


def best(gestures, buf, threshold):
    """Повертає жест, найближчий до останніх кадрів, якщо відстань менша за поріг."""
    if len(buf) < 3:
        return None
    now = buf[-1][0]
    best_g, best_d = None, threshold
    for g in gestures:
        tf = g.features
        if tf is None:
            continue
        for k in (0.7, 1.0, 1.4):  # допуск на швидкість руху
            w = max(g.duration * k, 300.0)
            window = [f for f in buf if f[0] >= now - w]
            if len(window) < 3 or window[-1][0] - window[0][0] < w * 0.7:
                continue
            f = features(window)
            if f is None:
                continue
            d = dist(tf, f)
            if d < best_d:
                best_d, best_g = d, g
    return best_g


def trim(raw):
    """Лишає тільки частину запису, де рука рухається."""
    if len(raw) < 6:
        return list(raw)
    e = [0.0]
    for i in range(1, len(raw)):
        e.append(float(np.mean(np.abs(raw[i][1] - raw[i - 1][1]))))
    th = 0.004
    idx = [i for i, v in enumerate(e) if v > th]
    if not idx or idx[-1] - idx[0] < 3:  # статична поза
        mid = len(raw) // 2
        return list(raw[max(0, mid - 5): mid + 5])
    return list(raw[max(0, idx[0] - 2): min(len(raw), idx[-1] + 2)])
