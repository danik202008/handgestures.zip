package com.handgestures

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

object ModelFile {
    private const val URL_STR =
        "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

    /** Завантажує модель при першому запуску (≈7 МБ), далі бере з пам'яті телефона. */
    fun ensure(ctx: Context): File {
        val f = File(ctx.filesDir, "hand_landmarker.task")
        if (f.exists() && f.length() > 1_000_000) return f
        val tmp = File(ctx.filesDir, "hand_landmarker.tmp")
        val c = URL(URL_STR).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        tmp.renameTo(f)
        return f
    }
}

class HandTracker(
    private val ctx: Context,
    private val onHand: (FloatArray?, Long) -> Unit
) {
    private var landmarker: HandLandmarker? = null

    fun init(model: File) {
        val bytes = model.readBytes()
        val buf = ByteBuffer.allocateDirect(bytes.size).put(bytes)
        buf.rewind()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(buf).build())
            .setNumHands(1)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ ->
                val lm = result.landmarks()
                if (lm.isEmpty()) {
                    onHand(null, result.timestampMs())
                } else {
                    val pts = FloatArray(63)
                    lm[0].forEachIndexed { i, p ->
                        pts[i * 3] = p.x(); pts[i * 3 + 1] = p.y(); pts[i * 3 + 2] = p.z()
                    }
                    onHand(pts, result.timestampMs())
                }
            }
            .setErrorListener { }
            .build()
        landmarker = HandLandmarker.createFromOptions(ctx, opts)
    }

    fun detect(img: ImageProxy, mirror: Boolean) {
        try {
            val lm = landmarker ?: return
            val bmp = img.toBitmap()
            val m = Matrix()
            m.postRotate(img.imageInfo.rotationDegrees.toFloat())
            if (mirror) m.postScale(-1f, 1f)
            val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            lm.detectAsync(BitmapImageBuilder(rot).build(), SystemClock.uptimeMillis())
        } finally {
            img.close()
        }
    }

    fun close() { landmarker?.close(); landmarker = null }
}
