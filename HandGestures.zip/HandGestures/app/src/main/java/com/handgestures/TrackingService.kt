package com.handgestures

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class TrackingService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.handgestures.STOP"
    }

    private var tracker: HandTracker? = null
    private var provider: ProcessCameraProvider? = null
    private lateinit var executor: ExecutorService
    private val buffer = ArrayDeque<Frame>()
    private var lastTrigger = 0L

    override fun onCreate() {
        super.onCreate()
        GestureStore.init(this)
        executor = Executors.newSingleThreadExecutor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, 1, notification(), type)
        if (tracker == null) startTracking()
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("hg", "Жести рукою", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "hg")
            .setContentTitle("Жести рукою активні")
            .setContentText("Камера стежить за рукою")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(Notification.Action.Builder(0, "Зупинити", stop).build())
            .setOngoing(true)
            .build()
    }

    private fun startTracking() {
        TrackingState.status.value = "Завантаження моделі руки…"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val model = ModelFile.ensure(this@TrackingService)
                val t = HandTracker(this@TrackingService) { pts, ts -> onHand(pts, ts) }
                t.init(model)
                tracker = t
                withContext(Dispatchers.Main) { bindCamera() }
            } catch (e: Exception) {
                TrackingState.status.value = "Помилка: ${e.message}"
                withContext(Dispatchers.Main) { stopSelf() }
            }
        }
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                @Suppress("DEPRECATION")
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 640))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { img -> tracker?.detect(img, true) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
                TrackingState.running.value = true
                TrackingState.status.value = "Працює. Покажи руку в камеру"
            } catch (e: Exception) {
                TrackingState.status.value = "Помилка камери: ${e.message}"
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onHand(pts: FloatArray?, t: Long) {
        if (pts == null) { TrackingState.hand.value = null; return }
        val f = Frame(t, pts)
        TrackingState.hand.value = f
        val rec = TrackingState.recorder
        if (rec != null) { rec(f); return }

        buffer.addLast(f)
        while (buffer.isNotEmpty() && buffer.first().t < t - 4000) buffer.removeFirst()
        if (t - lastTrigger < GestureStore.COOLDOWN_MS) return

        val g = Matcher.best(GestureStore.gestures.value, buffer, GestureStore.threshold.value) ?: return
        lastTrigger = t
        buffer.clear()
        val svc = GestureAccessibilityService.instance
        if (svc == null) {
            TrackingState.status.value = "Увімкни службу доступності, щоб жести виконувались"
        } else {
            svc.perform(g.action)
            TrackingState.status.value = "Спрацював: ${g.name}"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        provider?.unbindAll()
        tracker?.close()
        tracker = null
        executor.shutdown()
        TrackingState.running.value = false
        TrackingState.hand.value = null
        TrackingState.recorder = null
        TrackingState.status.value = "Вимкнено"
    }
}

fun startTracking(ctx: Context) =
    ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))

fun stopTracking(ctx: Context) {
    ctx.startService(Intent(ctx, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
}
