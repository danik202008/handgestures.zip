package com.handgestures

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import kotlinx.coroutines.delay

private val BONES = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4,
    0 to 5, 5 to 6, 6 to 7, 7 to 8,
    5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16,
    13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
)

/** Віртуальна рука: скелет із 21 точки. */
@Composable
fun HandView(pts: FloatArray?, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val p = pts ?: return@Canvas
        fun o(i: Int) = Offset(p[i * 3] * size.width, p[i * 3 + 1] * size.height)
        val sw = size.width * 0.014f
        for ((a, b) in BONES) drawLine(Color(0xFF4DD0E1), o(a), o(b), strokeWidth = sw, cap = StrokeCap.Round)
        for (i in 0..20) drawCircle(Color.White, sw * 0.9f, o(i))
    }
}

/** Відтворює записаний жест віртуальною рукою по колу. */
@Composable
fun GesturePlayer(g: Gesture, modifier: Modifier = Modifier) {
    var cur by remember(g.id) { mutableStateOf<FloatArray?>(null) }
    LaunchedEffect(g.id, g.frames.size) {
        if (g.frames.isEmpty()) return@LaunchedEffect
        while (true) {
            var prev = g.frames.first().t
            for (f in g.frames) {
                delay((f.t - prev).coerceIn(0, 200))
                prev = f.t
                cur = f.pts
            }
            delay(700)
        }
    }
    HandView(cur, modifier)
}
