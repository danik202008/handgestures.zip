package com.handgestures

import android.Manifest
import android.content.Context
import android.content.Intent
import android.app.Activity
import android.os.Build
import android.widget.Toast
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Collections
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GestureStore.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

fun isAccessibilityOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return false
    return s.contains(ctx.packageName + "/")
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val running by TrackingState.running.collectAsState()
    val status by TrackingState.status.collectAsState()
    val hand by TrackingState.hand.collectAsState()
    val gestures by GestureStore.gestures.collectAsState()
    val threshold by GestureStore.threshold.collectAsState()
    var accessOn by remember { mutableStateOf(false) }
    var showRecord by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { while (true) { accessOn = isAccessibilityOn(ctx); delay(1000) } }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.CAMERA] == true) startTracking(ctx)
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Жести рукою", style = MaterialTheme.typography.headlineMedium) }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Статус: $status")
                    Text(if (accessOn) "Служба доступності: увімкнена ✓" else "Служба доступності: вимкнена ✗")
                    if (!accessOn) {
                        Button(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }) { Text("Увімкнути (Жести рукою → Увімк.)") }
                    }
                    Button(onClick = {
                        if (running) stopTracking(ctx) else {
                            val need = mutableListOf(Manifest.permission.CAMERA)
                            if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
                            perms.launch(need.toTypedArray())
                        }
                    }) { Text(if (running) "Зупинити стеження" else "Запустити стеження") }
                    Button(onClick = { openTikTok(ctx) }) { Text("Відкрити TikTok") }
                    OutlinedButton(onClick = {
                        stopTracking(ctx)
                        (ctx as? Activity)?.finishAffinity()
                    }) { Text("Вимкнути програму") }
                    OutlinedButton(onClick = {
                        val svc = GestureAccessibilityService.instance
                        if (svc == null) Toast.makeText(ctx, "Спочатку увімкни службу доступності", Toast.LENGTH_LONG).show()
                        else svc.perform(GestureAction.LOCK_SCREEN)
                    }) { Text("Погасити екран") }
                    OutlinedButton(onClick = {
                        val svc = GestureAccessibilityService.instance
                        if (svc == null) Toast.makeText(ctx, "Спочатку увімкни службу доступності", Toast.LENGTH_LONG).show()
                        else svc.perform(GestureAction.POWER_MENU)
                    }) { Text("Вимкнути телефон") }
                }
            }
        }

        if (running) {
            item {
                Box(
                    Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF101820)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.fillMaxHeight().aspectRatio(3f / 4f)) {
                        HandView(hand?.pts, Modifier.fillMaxSize())
                    }
                    if (hand == null) Text("Руку не видно", color = Color.Gray)
                }
            }
        }

        item {
            Column {
                Text("Чутливість (ліво — точніше, право — легше спрацьовує)")
                Slider(value = threshold, onValueChange = { GestureStore.setThreshold(it) }, valueRange = 0.15f..0.6f)
            }
        }

        item { Text("Мої жести", style = MaterialTheme.typography.titleLarge) }

        items(gestures, key = { it.id }) { g -> GestureCard(g) }

        item {
            Button(onClick = { showRecord = true }, enabled = running, modifier = Modifier.fillMaxWidth()) {
                Text(if (running) "+ Записати новий жест" else "Спочатку запусти стеження")
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showRecord) RecordDialog { showRecord = false }
}

@Composable
fun GestureCard(g: Gesture) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.width(90.dp).aspectRatio(3f / 4f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF101820))) {
                GesturePlayer(g, Modifier.fillMaxSize())
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(g.name, style = MaterialTheme.typography.titleMedium)
                Box {
                    OutlinedButton(onClick = { menu = true }) { Text(g.action.title, maxLines = 2) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        GestureAction.values().forEach { a ->
                            DropdownMenuItem(text = { Text(a.title) }, onClick = {
                                GestureStore.update(g.with(action = a)); menu = false
                            })
                        }
                    }
                }
                TextButton(onClick = { GestureStore.delete(g.id) }) { Text("Видалити") }
            }
        }
    }
}

@Composable
fun RecordDialog(onClose: () -> Unit) {
    var phase by remember { mutableStateOf(0) }   // 0 старт, 1 відлік, 2 запис, 3 перегляд
    var count by remember { mutableStateOf(3) }
    var clip by remember { mutableStateOf<List<Frame>>(emptyList()) }
    var name by remember { mutableStateOf("") }
    var action by remember { mutableStateOf(GestureAction.NEXT_VIDEO) }
    var menu by remember { mutableStateOf(false) }
    val hand by TrackingState.hand.collectAsState()
    val scope = rememberCoroutineScope()

    fun start() {
        scope.launch {
            phase = 1
            for (i in 3 downTo 1) { count = i; delay(1000) }
            val list = Collections.synchronizedList(ArrayList<Frame>())
            TrackingState.recorder = { list.add(it) }
            phase = 2
            delay(2500)
            TrackingState.recorder = null
            clip = Matcher.trim(synchronized(list) { ArrayList(list) })
            phase = 3
        }
    }

    DisposableEffect(Unit) { onDispose { TrackingState.recorder = null } }

    AlertDialog(
        onDismissRequest = { if (phase != 1 && phase != 2) onClose() },
        title = { Text("Новий жест") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF101820)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.fillMaxHeight().aspectRatio(3f / 4f)) {
                        if (phase == 3 && clip.isNotEmpty())
                            GesturePlayer(Gesture("tmp", "", action, clip), Modifier.fillMaxSize())
                        else HandView(hand?.pts, Modifier.fillMaxSize())
                    }
                    when (phase) {
                        1 -> Text("$count", style = MaterialTheme.typography.displayLarge, color = Color.White)
                        2 -> Text("● ЗАПИС — роби жест!", color = Color.Red)
                    }
                }
                when (phase) {
                    0 -> Text("Натисни «Почати». Буде відлік 3 секунди, потім 2,5 секунди запису — зроби рух рукою перед камерою.")
                    3 -> if (clip.size < 3) {
                        Text("Руку не було видно. Спробуй ще раз.")
                    } else {
                        OutlinedTextField(name, { name = it }, label = { Text("Назва жесту") }, singleLine = true)
                        Box {
                            OutlinedButton(onClick = { menu = true }) { Text("Дія: ${action.title}") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                GestureAction.values().forEach { a ->
                                    DropdownMenuItem(text = { Text(a.title) }, onClick = { action = a; menu = false })
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            when (phase) {
                0 -> Button(onClick = { start() }) { Text("Почати") }
                3 -> if (clip.size >= 3) Button(onClick = {
                    GestureStore.add(Gesture(UUID.randomUUID().toString(), name.ifBlank { "Жест ${GestureStore.gestures.value.size + 1}" }, action, clip))
                    onClose()
                }) { Text("Зберегти") } else Button(onClick = { phase = 0 }) { Text("Ще раз") }
            }
        },
        dismissButton = {
            if (phase == 0 || phase == 3) {
                Row {
                    if (phase == 3 && clip.size >= 3) TextButton(onClick = { phase = 0 }) { Text("Перезаписати") }
                    TextButton(onClick = onClose) { Text("Скасувати") }
                }
            }
        }
    )
}
