package com.handgestures

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/** Виконує свайпи/тапи/«назад» у будь-якому застосунку (TikTok, Telegram…). */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun perform(a: GestureAction) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        handler.post {
            when (a) {
                GestureAction.NEXT_VIDEO -> swipe(w / 2, h * 0.75f, w / 2, h * 0.25f, 220)
                GestureAction.PREV_VIDEO -> swipe(w / 2, h * 0.25f, w / 2, h * 0.75f, 220)
                GestureAction.SWIPE_LEFT -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2, 220)
                GestureAction.SWIPE_RIGHT -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2, 220)
                GestureAction.TAP -> tap(w / 2, h / 2)
                GestureAction.DOUBLE_TAP -> { tap(w / 2, h / 2); handler.postDelayed({ tap(w / 2, h / 2) }, 120) }
                GestureAction.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
                GestureAction.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
                GestureAction.LOCK_SCREEN -> {
                    if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                    Unit
                }
                GestureAction.POWER_MENU -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
                GestureAction.STOP_APP -> {}   // обробляє TrackingService
                GestureAction.OPEN_TIKTOK -> openTikTok(this)
            }
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null
        )
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build(), null, null
        )
    }
}
