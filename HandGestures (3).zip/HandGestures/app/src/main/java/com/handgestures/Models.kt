package com.handgestures

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

enum class GestureAction(val title: String) {
    NEXT_VIDEO("Прогорнути вниз (наступне відео / чат)"),
    PREV_VIDEO("Прогорнути вгору (попереднє)"),
    SWIPE_LEFT("Свайп вліво"),
    SWIPE_RIGHT("Свайп вправо"),
    TAP("Тап по центру"),
    DOUBLE_TAP("Подвійний тап (лайк у TikTok)"),
    BACK("Назад"),
    HOME("Додому"),
    LOCK_SCREEN("Погасити екран (блокування)"),
    POWER_MENU("Меню вимкнення телефона"),
    STOP_APP("Вимкнути програму (зупинити стеження)"),
    OPEN_TIKTOK("Відкрити TikTok")
}

/** Один кадр руки: 21 точка * (x, y, z), нормалізовані 0..1 */
class Frame(val t: Long, val pts: FloatArray)

class Gesture(
    val id: String,
    val name: String,
    val action: GestureAction,
    val frames: List<Frame>
) {
    val durationMs: Long get() = if (frames.size < 2) 0 else frames.last().t - frames.first().t
    val features: FloatArray? by lazy { Matcher.features(frames) }
    fun with(name: String = this.name, action: GestureAction = this.action) =
        Gesture(id, name, action, frames)
}

object TrackingState {
    val hand = MutableStateFlow<Frame?>(null)
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("Вимкнено")
    @Volatile var recorder: ((Frame) -> Unit)? = null
}

object GestureStore {
    private var prefs: SharedPreferences? = null
    val gestures = MutableStateFlow<List<Gesture>>(emptyList())
    val threshold = MutableStateFlow(0.30f)
    const val COOLDOWN_MS = 1500L

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("hg", Context.MODE_PRIVATE)
        prefs = p
        threshold.value = p.getFloat("threshold", 0.30f)
        val raw = p.getString("gestures", null) ?: return
        try {
            val arr = JSONArray(raw)
            val list = ArrayList<Gesture>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val fr = o.getJSONArray("frames")
                val frames = ArrayList<Frame>()
                for (j in 0 until fr.length()) {
                    val fo = fr.getJSONObject(j)
                    val pa = fo.getJSONArray("p")
                    val pts = FloatArray(pa.length()) { pa.getDouble(it).toFloat() }
                    frames.add(Frame(fo.getLong("t"), pts))
                }
                list.add(
                    Gesture(
                        o.getString("id"), o.getString("name"),
                        runCatching { GestureAction.valueOf(o.getString("action")) }
                            .getOrDefault(GestureAction.NEXT_VIDEO),
                        frames
                    )
                )
            }
            gestures.value = list
        } catch (_: Exception) { }
    }

    private fun persist() {
        val arr = JSONArray()
        for (g in gestures.value) {
            val o = JSONObject()
            o.put("id", g.id); o.put("name", g.name); o.put("action", g.action.name)
            val fr = JSONArray()
            for (f in g.frames) {
                val fo = JSONObject()
                fo.put("t", f.t)
                val pa = JSONArray()
                for (v in f.pts) pa.put(Math.round(v * 1000f) / 1000.0)
                fo.put("p", pa)
                fr.put(fo)
            }
            o.put("frames", fr)
            arr.put(o)
        }
        prefs?.edit()?.putString("gestures", arr.toString())?.apply()
    }

    fun add(g: Gesture) { gestures.value = gestures.value + g; persist() }
    fun update(g: Gesture) { gestures.value = gestures.value.map { if (it.id == g.id) g else it }; persist() }
    fun delete(id: String) { gestures.value = gestures.value.filter { it.id != id }; persist() }
    fun setThreshold(v: Float) { threshold.value = v; prefs?.edit()?.putFloat("threshold", v)?.apply() }
}
