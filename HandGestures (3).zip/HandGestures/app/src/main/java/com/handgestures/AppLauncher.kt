package com.handgestures

import android.content.Context
import android.content.Intent
import android.widget.Toast

private val TIKTOK_PACKAGES = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")

/** Відкриває встановлений TikTok (звичайна або азіатська версія). */
fun openTikTok(ctx: Context) {
    val intent = TIKTOK_PACKAGES.firstNotNullOfOrNull { ctx.packageManager.getLaunchIntentForPackage(it) }
    if (intent == null) {
        Toast.makeText(ctx, "TikTok не встановлено", Toast.LENGTH_LONG).show()
        return
    }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(intent)
}
