package com.handgestures

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

object Matcher {
    private const val N = 16      // кількість точок після передискретизації
    private const val D = 65      // 63 координати форми + 2 зсуву зап'ястя

    private fun palm(p: FloatArray): Float {
        val dx = p[0] - p[27]
        val dy = p[1] - p[28]
        return max(sqrt(dx * dx + dy * dy), 0.02f)
    }

    private fun frameAt(frames: List<Frame>, t: Long): FloatArray {
        var best = frames[0]
        var bd = Long.MAX_VALUE
        for (f in frames) {
            val d = abs(f.t - t)
            if (d < bd) { bd = d; best = f }
        }
        return best.pts
    }

    /** Форма руки (відносно зап'ястя) + траєкторія зап'ястя, нормовані розміром долоні. */
    fun features(frames: List<Frame>): FloatArray? {
        if (frames.size < 3) return null
        val t0 = frames.first().t
        val dur = (frames.last().t - t0).coerceAtLeast(1)
        val first = frames.first().pts
        val scale = palm(first)
        val out = FloatArray(N * D)
        for (i in 0 until N) {
            val f = frameAt(frames, t0 + dur * i / (N - 1))
            val wx = f[0]; val wy = f[1]; val wz = f[2]
            for (j in 0 until 21) {
                out[i * D + j * 3] = (f[j * 3] - wx) / scale
                out[i * D + j * 3 + 1] = (f[j * 3 + 1] - wy) / scale
                out[i * D + j * 3 + 2] = (f[j * 3 + 2] - wz) / scale
            }
            out[i * D + 63] = (wx - first[0]) / scale * 3f
            out[i * D + 64] = (wy - first[1]) / scale * 3f
        }
        return out
    }

    private fun dist(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) { val d = a[i] - b[i]; s += d * d }
        return sqrt(s / a.size)
    }

    /** Повертає жест, найближчий до останніх кадрів, якщо відстань менша за поріг. */
    fun best(gs: List<Gesture>, buf: List<Frame>, threshold: Float): Gesture? {
        if (buf.size < 3) return null
        val now = buf.last().t
        var bestG: Gesture? = null
        var bestD = threshold
        for (g in gs) {
            val tf = g.features ?: continue
            for (k in floatArrayOf(0.7f, 1f, 1.4f)) {   // допуск на швидкість руху
                val w = (g.durationMs * k).toLong().coerceAtLeast(300)
                val window = buf.filter { it.t >= now - w }
                if (window.size < 3) continue
                if (window.last().t - window.first().t < w * 0.7) continue
                val f = features(window) ?: continue
                val d = dist(tf, f)
                if (d < bestD) { bestD = d; bestG = g }
            }
        }
        return bestG
    }

    /** Обрізає запис: лишає тільки частину, де рука рухається. */
    fun trim(raw: List<Frame>): List<Frame> {
        if (raw.size < 6) return raw
        val e = FloatArray(raw.size)
        for (i in 1 until raw.size) {
            var s = 0f
            for (k in 0 until 63) s += abs(raw[i].pts[k] - raw[i - 1].pts[k])
            e[i] = s / 63f
        }
        val th = 0.004f
        val first = e.indexOfFirst { it > th }
        val last = e.indexOfLast { it > th }
        if (first < 0 || last - first < 3) {   // статична поза
            val mid = raw.size / 2
            return raw.subList(maxOf(0, mid - 5), minOf(raw.size, mid + 5))
        }
        return raw.subList(maxOf(0, first - 2), minOf(raw.size, last + 2))
    }
}
